import prompt
from random import randint


def game():
    attempt = 3
    random_number = randint(1, 100)

    while attempt:
        print('Welcome to the Brain Games!')
        user_name = prompt.string('May I have your name? ')
        print(f"Hello, {user_name}!")
        print("Answer 'yes' if the number is even, otherwise answer 'no'.")
        print(f'Question: {random_number}')
        user_answer = prompt.string('Your answer: ')
        if (user_answer == 'yes' and random_number % 2 == 0) or (user_answer == 'no' and random_number % 2 != 0):
            return 'Correct!'
        elif user_answer == 'yes' and random_number % 2 != 0:
            return f"'yes' is wrong answer ;(. Correct answer was 'no'. \n Let's try again, {user_name}!"
        elif user_answer == 'no' and random_number % 2 == 0:
            return f"'no' is wrong answer ;(. Correct answer was 'yes'. \n Let's try again, {user_name}!"
    attempt -= 1


if __name__ == '__main__':
    game()
