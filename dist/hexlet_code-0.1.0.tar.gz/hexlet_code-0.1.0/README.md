### Hexlet tests and linter status:
[![Actions Status](https://github.com/konserge/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/konserge/python-project-49/actions)

https://asciinema.org/a/QU2RqEPX3BNCxd1rVwvRZT9aG

https://asciinema.org/a/uY19bOrwr6glunxhmbSHy4uA7

https://asciinema.org/a/4S7uPNTt0VtiDjH31bIEhYkIG
