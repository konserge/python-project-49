### Hexlet tests and linter status:
[![Actions Status](https://github.com/konserge/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/konserge/python-project-49/actions)

https://asciinema.org/a/QU2RqEPX3BNCxd1rVwvRZT9aG

